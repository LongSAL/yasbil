<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://github.com/yasbil/yasbil
 * @since             1.0.0
 * @package           YASBIL_WP
 *
 * @wordpress-plugin
 * Plugin Name:       YABIL WP
 * Plugin URI:        https://github.com/yasbil/yasbil
 * Description:       YASBIL: Yet Another Search Behaviour (and) Interaction Logger
 * Version:           2.1.0
 * Author:            Nilavra Bhattacharya
 * Author URI:        https://nilavra.in
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       yasbil-wp
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 *
 * Changelogs in docs/changelog-wp.md
 */
define( 'YASBIL_WP_VERSION', '2.1.0' );
//define( 'PLUGIN_NAME_VERSION', '1.0.0' );

global $yasbil_wp_db_version;
$yasbil_wp_db_version = '2.0';

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-yasbil-wp-activator.php
 */
function activate_yasbil_wp() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-yasbil-wp-activator.php';
	YASBIL_WP_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-yasbil-wp-deactivator.php
 */
function deactivate_yasbil_wp() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-yasbil-wp-deactivator.php';
	YASBIL_WP_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_yasbil_wp' );
register_deactivation_hook( __FILE__, 'deactivate_yasbil_wp' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-yasbil-wp.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_yasbil_wp() {

	$plugin = new YASBIL_WP();
	$plugin->run();

}
run_yasbil_wp();
